package com.example.recetarioparacocina;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private LinearLayout contenedorRecetas;
    private TextView tvCantidad;
    private TextView tvVacio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        dbHelper = new DBHelper(this);

        contenedorRecetas = findViewById(R.id.contenedorRecetas);
        tvCantidad = findViewById(R.id.tvCantidad);
        tvVacio = findViewById(R.id.tvVacio);

        Button btnNueva = findViewById(R.id.btnNuevaReceta);
        Button btnBuscar = findViewById(R.id.btnBuscarRecetas);

        btnNueva.setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));

        btnBuscar.setOnClickListener(v ->
                startActivity(new Intent(this, BuscarActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarRecetas();
    }

    private void cargarRecetas() {
        contenedorRecetas.removeAllViews();

        Cursor cursor = dbHelper.obtenerRecetas();
        int cantidad = 0;

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    cantidad++;

                    int id = cursor.getInt(
                            cursor.getColumnIndexOrThrow("id"));

                    String nombre = cursor.getString(
                            cursor.getColumnIndexOrThrow("nombre"));

                    String foto = cursor.getString(
                            cursor.getColumnIndexOrThrow("foto"));

                    agregarTarjeta(id, nombre, foto);
                }
            } finally {
                cursor.close();
            }
        }

        tvCantidad.setText(cantidad +
                (cantidad == 1 ? " receta" : " recetas"));

        tvVacio.setVisibility(
                cantidad == 0 ? android.view.View.VISIBLE
                        : android.view.View.GONE);
    }

    private void agregarTarjeta(int id, String nombre, String foto) {
        LinearLayout tarjeta = new LinearLayout(this);
        tarjeta.setOrientation(LinearLayout.HORIZONTAL);
        tarjeta.setGravity(Gravity.CENTER_VERTICAL);
        tarjeta.setPadding(12, 12, 12, 12);

        GradientDrawable fondo = new GradientDrawable();
        fondo.setColor(Color.WHITE);
        fondo.setCornerRadius(20);
        tarjeta.setBackground(fondo);
        tarjeta.setElevation(3);

        LinearLayout.LayoutParams parametros =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);

        parametros.bottomMargin = 16;
        contenedorRecetas.addView(tarjeta, parametros);

        ImageView imagen = new ImageView(this);
        imagen.setScaleType(ImageView.ScaleType.CENTER_CROP);

        LinearLayout.LayoutParams parametrosImagen =
                new LinearLayout.LayoutParams(92, 92);

        imagen.setBackgroundColor(Color.rgb(239, 239, 229));

        if (foto != null && !foto.isEmpty()) {
            try {
                imagen.setImageURI(Uri.parse(foto));
            } catch (Exception e) {
                imagen.setImageResource(
                        android.R.drawable.ic_menu_gallery);
            }
        } else {
            imagen.setImageResource(
                    android.R.drawable.ic_menu_gallery);
        }

        tarjeta.addView(imagen, parametrosImagen);

        LinearLayout informacion = new LinearLayout(this);
        informacion.setOrientation(LinearLayout.VERTICAL);
        informacion.setPadding(14, 4, 4, 4);

        LinearLayout.LayoutParams parametrosInfo =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1);

        tarjeta.addView(informacion, parametrosInfo);

        TextView titulo = new TextView(this);
        titulo.setText(nombre == null || nombre.trim().isEmpty()
                ? "Receta sin nombre" : nombre);
        titulo.setTextColor(Color.rgb(36, 59, 42));
        titulo.setTextSize(17);
        titulo.setTypeface(null, Typeface.BOLD);

        informacion.addView(titulo);

        TextView descripcion = new TextView(this);
        descripcion.setText("Ver detalles de la receta");
        descripcion.setTextColor(Color.rgb(110, 117, 105));
        descripcion.setTextSize(13);
        descripcion.setPadding(0, 8, 0, 0);

        informacion.addView(descripcion);

        tarjeta.setOnClickListener(v -> {
            Intent intent = new Intent(this, BuscarActivity.class);
            intent.putExtra("receta_id", id);
            startActivity(intent);
        });
    }
}
