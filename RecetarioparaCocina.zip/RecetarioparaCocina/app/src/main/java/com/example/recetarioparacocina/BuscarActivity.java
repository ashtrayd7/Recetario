package com.example.recetarioparacocina;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class BuscarActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText txtBuscar;
    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar);

        dbHelper = new DBHelper(this);

        txtBuscar = findViewById(R.id.txtBuscar);
        lista = findViewById(R.id.lista);

        findViewById(R.id.btnNombre).setOnClickListener(v -> {
            buscarNombre();
        });

        findViewById(R.id.btnIngrediente).setOnClickListener(v -> {
            buscarIngrediente();
        });
    }

    private void buscarNombre() {
        String texto = txtBuscar.getText().toString().trim();

        if (texto.isEmpty()) {
            txtBuscar.setError("Escribe el nombre de una receta");
            return;
        }

        Cursor cursor = dbHelper.buscarPorNombre(texto);
        mostrarResultados(cursor);
    }

    private void buscarIngrediente() {
        String texto = txtBuscar.getText().toString().trim();

        if (texto.isEmpty()) {
            txtBuscar.setError("Escribe un ingrediente");
            return;
        }

        Cursor cursor = dbHelper.buscarPorIngrediente(texto);
        mostrarResultados(cursor);
    }

    private void mostrarResultados(Cursor cursor) {
        ArrayList<String> recetas = new ArrayList<>();

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    String nombre = cursor.getString(
                            cursor.getColumnIndexOrThrow("nombre")
                    );

                    if (!recetas.contains(nombre)) {
                        recetas.add(nombre);
                    }
                }
            } finally {
                cursor.close();
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                recetas
        );

        lista.setAdapter(adapter);

        if (recetas.isEmpty()) {
            Toast.makeText(
                    this,
                    "No se encontraron recetas",
                    Toast.LENGTH_SHORT
            ).show();
        } else {
            Toast.makeText(
                    this,
                    "Recetas encontradas: " + recetas.size(),
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
